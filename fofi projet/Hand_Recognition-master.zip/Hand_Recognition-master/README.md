# Hand_Recognition
Basic hand gesture recognition programme in python using an open source library OpenCV.
https://www.youtube.com/watch?v=LYw9RzS54OI
